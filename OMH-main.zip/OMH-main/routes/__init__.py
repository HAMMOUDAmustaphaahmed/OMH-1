# Ce fichier est nécessaire pour que le répertoire routes soit considéré comme un package Python
# Il peut être vide, ou vous pouvez y mettre du code d'initialisation commun à tous les blueprints